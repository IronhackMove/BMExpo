const axios = require('axios')
const User  = require('../../models/User');

class apiDB {

    constructor() {

    }

    async saveUserInfo(userInfo) {

     
    }

}

module.exports = apiDB;
