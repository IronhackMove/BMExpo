const express = require('express');
const router  = express.Router();

/* GET home page */
router.get('/', (req, res, next) => {
  res.json({message: "esta es la página principal"});
});

router.use('/', require('./auth'));
// router.use('/authLinkedIn', require('./authLinkedIn'));

module.exports = router;
