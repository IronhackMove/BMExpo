const express = require("express");
const passport = require("passport");
const router = express.Router();
const User = require("../models/User");
const Chat = require("../models/Chat");
const ChatMessage = require("../models/ChatMessage");
const Category = require("../models/Category");
const ContactNote = require("../models/ContactNote");
const apiDB = require("../public/javascripts/apiDB");
const api = new apiDB();
const axios = require("axios");
const _ = require("lodash");

function intersect(a, b) {
  var t;
  if (b.length > a.length) (t = b), (b = a), (a = t); // indexOf to loop over shorter
  return a.filter(function(e) {
    return b.indexOf(e) > -1;
  });
}

router.get("/favicon.ico", (req, res) => res.status(204));

router.get("/auth/linkedIn/callback", (req, res) => {
  res.json({ message: "linkedIn ok" });
});

router.post("/auth/getCommonChat", (req, res) => {
  User.findOne({ id: req.body.userId })
    .then(user => {
      User.findOne({ id: req.body.contactId }).then(contact => {
        let idChat = intersect(user.chats, contact.chats);
        res.status(200).json(idChat[0]);
      });
    })
    .catch(err => console.log(err));
});

router.get("/auth/sayHello", (req, res) => {
  res.json({ message: "hola" });
});

router.get("/auth/getCategories", (req, res) => {
  Category.find().then(categories => res.status(200).json(categories));
});

router.get("/auth/getChatMessages/:chatId", (req, res) => {
  Chat.findOne({ _id: req.params.chatId })
    .populate("messages")
    .then(chat => {
      res.status(200).json(chat);
    });
});

router.get("/auth/getUserProfile/:token", (req, res) => {
  User.findOne({ access_token: req.params.token })
    .populate("selectedCategories")
    .then(user => {
      res.status(200).json(user);
    });
});

router.get("/auth/getUserMeetups/:token", (req, res) => {
  User.findOne({ access_token: req.params.token }).then(user => {
    res.status(200).json(user.meetups);
  });
});

router.get("/auth/getContactsUser/:token", (req, res) => {
  User.findOne({ access_token: req.params.token })
    .populate("contacts.contact")
    .then(user => {
      res.status(200).json(user);
    });
});

router.post("/auth/saveMeetups/:token", (req, res) => {
  User.findOneAndUpdate(
    { access_token: req.params.token },
    { $set: { meetups: req.body.meetups } }
  )
    .then(user => res.status(200).json(user))
    .catch(err => console.log(error));
});

router.post("/auth/getUserProfile/:linkedIn", (req, res) => {
  User.findOne({ id: req.params.linkedIn })
    .populate("contactnotes")
    .then(user => {
      res.status(200).json(user);
    });
});

router.post("/auth/saveCategories/:token", (req, res) => {
  var arraySelectedCategories = req.body.selectedCategories.map(
    selectedCategory => {
      return selectedCategory._id;
    }
  );

  User.findOneAndUpdate(
    { access_token: req.params.token },
    {
      firstSignup: false,
      $set: { selectedCategories: arraySelectedCategories }
    }
  ).then(user => {
    res.status(200).json(user);
  });
});

router.post("/auth/updateUserProfile/:token", (req, res) => {
  console.log(req.body.phone);
  User.findOneAndUpdate(
    { access_token: req.params.token },
    { $set: { emailAddress: req.body.email, phoneNumber: req.body.phone } }
  )
    .then(user => res.status(200).json({ message: "todo ok" }))
    .catch(err => console.log(error));
});

router.get("/auth/getContactNote/:idContact", (req, res) => {
  ContactNote.findOne({ id: req.params.idContact }).then(note =>
    res.status(200).json(note)
  );
});

router.post("/auth/addTags/", (req, res) => {
  console.log(req.body.tags);

  User.findOne({ id: req.body.idContact }).then(contactUser => {
    User.findOne({
      $and: [
        { access_token: req.body.token },
        { "contacts.contact": contactUser._id }
      ]
    }).then(contact => {
        console.log("hola")
        User.updateOne(
          {
            $and: [
              { access_token: req.body.token },
              { "contacts.contact": contactUser._id }
            ]
          },
          { $set: { "contacts.$.tags": req.body.tags } }
        ).then(user => res.status(200).json({ user }));
    });
  })
  .catch(err => res.status(500).json({ message: err }));
});

router.post("/auth/addContactNote/", (req, res) => {
  newNote = {
    idContact: req.body.idContact,
    note: req.body.note
  };

  User.findOne({
    $and: [
      { access_token: req.body.token },
      { "notes.idContact": req.body.idContact }
    ]
  })
    .then(note => {
      if (note !== null) {
        console.log("nota encontrada");
        User.updateOne(
          {
            $and: [
              { access_token: req.body.token },
              { "notes.idContact": req.body.idContact }
            ]
          },
          {
            $set: {
              "notes.$.note": req.body.note
            }
          }
        ).then(user =>
          res.status(200).json({ message: { message: "note updated" } })
        );
      } else {
        console.log("nota no encontrada");
        User.findOneAndUpdate(
          { access_token: req.body.token },
          { $push: { notes: newNote } }
        ).then(user => res.status(200).json({ message: "saved created" }));
      }
    })
    .catch(err => res.status(500).json({ message: err }));
});

router.post("/auth/checkContactSaved/", (req, res) => {
  console.log(req.body.ids)

  User.findOne({ id: req.body.ids[1]})
  .then(userContact => {
    User.findOne({
      $and: [
        { id: req.body.ids[0] },
        { "contacts.contact": userContact._id }
      ]
    }).then(user => {
      if (user !== null) {
        res.status(200).json({message: "User already saved"})
      } else {
        res.status(200).json(user)
      }
    }) 
  })
});

router.post("/auth/saveUsereData/", (req, res, next) => {
  // let query = { access_token: req.body.access_token };
  // let userLinkedin;

  console.log(req.body.id);

  User.findOne({ id: req.body.id }).then(user => {
    var userLinkedin;

    if (user) {
      console.log("encontrado");
      userLinkedin = { ...req.body, firstSignup: false };

      User.findOneAndUpdate(
        { id: req.body.id },
        userLinkedin,
        { upsert: true },
        (err, user) => {
          if (err) {
            console.log(err);
          } else {
            console.log(user);
          }
        }
      ).then(user => res.status(200).json(user));
    } else {
      userLinkedin = new User(req.body);
      userLinkedin.save().then(user => res.status(200).json(user));
    }
  });
});

module.exports = router;
