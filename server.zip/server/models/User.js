const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const userSchema = new Schema(
  {
    id: String,
    firstName: String,
    lastName: String,
    headline: String,
    emailAddress: String,
    access_token: String,
    pictureUrl: String,
    pictureUrls: Object,
    industry: String,
    positions: { type: Array },
    publicProfileUrl: String,
    summary: String,
    meetup: String,
    eventCategory: Array,
    firstSignup: { type: Boolean, default: true },
    phoneNumber: String,
    notes: Array,
    meetups: Object,
    chats: [{ type: Schema.Types.ObjectId, ref: "Chat" }],
    selectedCategories: [{ type: Schema.Types.ObjectId, ref: "Category" }],
    contacts: [
      {
        _id: false,
        contact: { type: Schema.Types.ObjectId, ref: "User" },
        meetup: String
      }
    ]
  },
  {
    timestamps: {
      createdAt: "created_at",
      updatedAt: "updated_at"
    }
  }
);

const User = mongoose.model("User", userSchema);
module.exports = User;
