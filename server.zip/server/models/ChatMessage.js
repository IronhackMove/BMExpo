const mongoose = require('mongoose');
const Schema   = mongoose.Schema;

const messageChatSchema = new Schema({
       text: String,
       user: Object,
       createdAt: String
});

const ChatMessage = mongoose.model('ChatMessage', messageChatSchema);
module.exports = ChatMessage;
