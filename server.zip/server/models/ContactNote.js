const mongoose = require('mongoose');
const Schema   = mongoose.Schema;

const contactNotesSchema = new Schema({
    idContact: String,
    note: String,
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at'
  }
});

const ContactNote = mongoose.model('ContactNote', contactNotesSchema);
module.exports = ContactNote;
