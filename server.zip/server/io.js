
const User = require("./models/User");
const Chat = require("./models/Chat");
const ChatMessage = require("./models/ChatMessage");

module.exports = (io) => {
    console.log("Socketio listening...");

    io.on('connection', function(socket){
        console.log(`A user connected with id: ${socket.id}`);
        console.log(socket.handshake.headers.cookie);    
        

        socket.on('send', data => {

            console.log("Received message from client");

            let { text, user, createdAt, _id } = data.message[0]
            let newMessage = new ChatMessage({
                text,
                user,
                createdAt,
            })

            newMessage.save()
            .then(message => {
                Chat.findOneAndUpdate(
                    { _id: data.chatId},
                    { $addToSet: { messages: message._id }}
                ).then(chat => chat)
            })
        
            socket.broadcast.emit('receiver', data);
        })

        socket.on('updateContact', data => {

            console.log(data)
  
            newChat = new Chat({
              messages: []
            })
          
            newChat.save()
            .then(chat =>{
              console.log(chat._id)
              User.findOne({ id: data.contactUserId }).then(userContact => {
                console.log(userContact)
                User.findOneAndUpdate(
                  { id: data.userId },
                  { $addToSet: { contacts: {contact: userContact._id, meetup: data.meetups}, chats: chat._id } }
                ).then(userApp => {
                  console.log(userApp)
                  User.findOneAndUpdate(
                    { id: data.contactUserId },
                    { $addToSet: { contacts: {contact: userApp._id, meetup: data.meetups}, chats: chat._id } }
                  ).then(user => console.log("user saved"));
                });
              });
            
            })
        
            socket.broadcast.emit('updateContact', data);
        })

        // socket.on('receiver', data => {

        //     console.log("Received message from client");

        //     let { text, user, createdAt, _id } = data.message[0]
        //     let newMessage = new ChatMessage({
        //         text,
        //         user,
        //         createdAt,
        //     })

        //     newMessage.save()
        //     .then(message => {
        //         Chat.findOneAndUpdate(
        //             { _id: data.chatId[0]},
        //             { $push: { messages: message._id }}
        //         ).then(chat => console.log(chat))
        //     })
        
        //     socket.broadcast.emit('receiver', data);
        // })



        

    });

    

}