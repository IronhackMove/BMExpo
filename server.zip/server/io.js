
const User = require("./models/User");
const Chat = require("./models/Chat");
const ChatMessage = require("./models/ChatMessage");

module.exports = (io) => {
    console.log("Socketio listening...");

    io.on('connection', (client) => {

        console.log(`A user connected with id: ${client.id}`);
        console.log(client.handshake.headers.cookie);    
        

        client.on('send', data => {

            console.log("Received message from client");

            let { text, user, createdAt, _id } = data.message[0]
            let newMessage = new ChatMessage({
                text,
                user,
                createdAt,
            })

            newMessage.save()
            .then(message => {
                Chat.findOneAndUpdate(
                    { _id: data.chatId},
                    { $addToSet: { messages: message._id }}
                ).then(chat => chat)
            })
        
            client.broadcast.emit('receiver', data);
        })

        client.on('updateContact', (data) => {
  
            newChat = new Chat({
              messages: []
            })

            User.findOne({ id: data.contactUserId }).then(userContact => {
                User.findOne({
                  $and: [
                    { id: data.userId },
                    { "contacts.contact": userContact._id }
                  ]
                }).then(user => {
                    if (user === null) {
                        newChat.save()
                        .then(chat =>{
                          console.log(chat._id)
                          User.findOne({ id: data.contactUserId }).then(userContact => {
                            console.log(userContact)
                            User.findOneAndUpdate(
                              { id: data.userId },
                              { $addToSet: { contacts: {contact: userContact._id, meetup: data.meetups}, chats: chat._id } }
                            ).then(userApp => {
                              User.findOneAndUpdate(
                                { id: data.contactUserId },
                                { $addToSet: { contacts: {contact: userApp._id, meetup: data.meetups}, chats: chat._id } }
                              ).then(reponse => client.broadcast.emit("updateContactList", data))
                            });
                          });
                        })
                    } else {
                        let message = "User already saved"
                        client.broadcast.emit("updateContactList", data)
                    }
                })
            })
          
    

            
        
          
        })

        // socket.on('receiver', data => {

        //     console.log("Received message from client");

        //     let { text, user, createdAt, _id } = data.message[0]
        //     let newMessage = new ChatMessage({
        //         text,
        //         user,
        //         createdAt,
        //     })

        //     newMessage.save()
        //     .then(message => {
        //         Chat.findOneAndUpdate(
        //             { _id: data.chatId[0]},
        //             { $push: { messages: message._id }}
        //         ).then(chat => console.log(chat))
        //     })
        
        //     socket.broadcast.emit('receiver', data);
        // })



        

    });

    

}